try:
    l=[1,2,3]
    print(l[3])
except:
    print("it has index error")